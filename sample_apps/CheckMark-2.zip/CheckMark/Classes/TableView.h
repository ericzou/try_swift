//
//  TableView.h
//  CheckMark
//
//  Created by Chakra on 03/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TableView : UITableViewController {

@private
	NSMutableArray *dataArray;
	
}

@end
